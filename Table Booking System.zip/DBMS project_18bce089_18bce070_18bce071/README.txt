			------------Restaurant Table Management----------------


>Download Mysql,Install it .Link=https://dev.mysql.com/get/Downloads/MySQLInstaller/mysql-installer-community-8.0.19.0.msi
>Mysql-Connecter-java,install it link=https://downloads.mysql.com/archives/get/p/3/file/mysql-connector-java-8.0.18.zip;
Set classpath through command prompt:
-set classpath="set path mysql-connector-java.jar";
>Download Javafx;
Move sql-folder(Project-folder) into {C:\ProgramData\Mysql\Mysql server\Data\[Project]};
for localhost:
	-go {src\DBconnection} folder
	-change username ,password,url into Configs.java;
Run into WindowsCommandLinePrompt:-
	-syntext [java -jar C:\user\downloads\ResturentManagement\out\artifacts\ResturentManagement_jar\RestaurentManagement.jar   ]		
And chage image path from src\controller\loginmainpage;

Further details see Video.

Project By:
18BCE089 Pranav Kansagra
18BCE070 Gaurav Vaghasiya
18BCE070 Gaurav Parekhiya
