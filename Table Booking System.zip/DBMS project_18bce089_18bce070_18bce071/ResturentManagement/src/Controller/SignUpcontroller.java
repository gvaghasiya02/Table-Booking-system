package Controller;


import DBconnection.DBhandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;


public class SignUpcontroller implements Initializable {
    private int aa=2;
    @FXML
    private PasswordField Password;

    @FXML
    private TextField E_mail;

    @FXML
    private Button SignUp;

    @FXML
    private TextField Username;

    @FXML
    private TextField Mobileno;

    @FXML
    private TextArea Adress;

    @FXML
    private PasswordField Repassword;

    @FXML
    private Label signupmessage;

    private Connection connection;
    private DBhandler handler;
    private PreparedStatement pst;
    private PreparedStatement pst1;
    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void Signupaction(ActionEvent event) throws SQLException {
        handler = new DBhandler();
        String pass, pass1;
        pass = Password.getText();
        pass1 = Repassword.getText();
        if (!pass.equals(pass1)) {
            String ab= signupmessage.textProperty().get();
            signupmessage.textProperty().set(" password is invalid");
        } else {
            System.out.println("p");

            //Saving Data


            String insert = "INSERT INTO customer (C_ID,name,Email,MobileNo,Address) Values"
                    + "(?,?,?,?,?)";
            String ins = "insert into login (name,c_ID,Password) Values (?,?,?)";
            System.out.println("p");
            connection = handler.getConnection();

            System.out.println("p");
            try {
                System.out.println("p");
                pst1=connection.prepareStatement(ins);
                pst = connection.prepareStatement(insert);
                System.out.println("p");
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            try {
                String ss= "" + ++aa;
                if(ss.length()==1){
                    ss="00"+aa;

                }
                else if(ss.length()==2)
                {
                    ss="0"+aa;

                }

                pst.setString(1, cidgenerater.s +ss);
                pst.setString(2, Username.getText());
                pst.setString(3, E_mail.getText());
                pst.setString(4, Mobileno.getText());
                pst.setString(5,
                        Adress.getText());
                pst1.setString(1,Username.getText());
                pst1.setString(2,cidgenerater.s + (aa));
                pst1.setString(3,Password.getText());
                pst.executeUpdate();
                pst1.executeUpdate();
                System.out.println("p");

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            finally {
                connection.close();
            }
            SignUp.getScene().getWindow().hide();


        }
    }


}


