package Controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static javafx.fxml.FXMLLoader.load;

public class administratorController implements Initializable {

    @FXML
    private Button ReservationTable;

    @FXML
    private Button customertable;

    @FXML
    private Button modyfy;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
    public void reservationtable(javafx.event.ActionEvent event)
    {
        Stage signup=new Stage();
        Parent root= null;
        try {
            root = load(getClass().getResource("/FXML/ReservationTable.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        signup.setTitle("Reservation Table");
        Scene scene= new Scene(root);
        signup.setScene(scene);
        signup.show();
        signup.setResizable(false);
    }
    public void customertable(javafx.event.ActionEvent event)
    {
        Stage signup=new Stage();
        Parent root= null;
        try {
            root = load(getClass().getResource("/FXML/CustomerTable.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        signup.setTitle("Customer Table");
        Scene scene= new Scene(root);
        signup.setScene(scene);
        signup.show();
        signup.setResizable(false);
    }

    public void pressReserve(javafx.event.ActionEvent event){
        Stage signup=new Stage();
        Parent root= null;
        try {
            root = load(getClass().getResource("/FXML/EditSql.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        signup.setTitle("Modify");
        Scene scene= new Scene(root);
        signup.setScene(scene);
        signup.show();
        signup.setResizable(false);
    }



}
