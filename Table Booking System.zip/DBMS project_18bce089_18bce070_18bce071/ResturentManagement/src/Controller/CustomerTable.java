package Controller;

import javafx.beans.property.SimpleStringProperty;

public class CustomerTable {
    private final SimpleStringProperty C_ID;
    private final SimpleStringProperty C_Name;
    private final SimpleStringProperty E_mail;
    private final SimpleStringProperty MobileNo;
    private final SimpleStringProperty Adress;

    public String getC_ID() {
        return C_ID.get();
    }

    public SimpleStringProperty c_IDProperty() {
        return C_ID;
    }

    public String getC_Name() {
        return C_Name.get();
    }

    public SimpleStringProperty c_NameProperty() {
        return C_Name;
    }

    public String getE_mail() {
        return E_mail.get();
    }

    public SimpleStringProperty e_mailProperty() {
        return E_mail;
    }

    public String getMobileNo() {
        return MobileNo.get();
    }

    public SimpleStringProperty mobileNoProperty() {
        return MobileNo;
    }

    public String getAdress() {
        return Adress.get();
    }

    public SimpleStringProperty adressProperty() {
        return Adress;
    }

    public CustomerTable(String c_id, String mobileNo, String adress, String e_mail, String c_name ) {
        C_ID = new SimpleStringProperty(c_id);
        C_Name = new SimpleStringProperty(c_name);
        E_mail = new SimpleStringProperty( e_mail);
        MobileNo = new SimpleStringProperty( mobileNo);
        Adress =new SimpleStringProperty( adress);

    }
}
