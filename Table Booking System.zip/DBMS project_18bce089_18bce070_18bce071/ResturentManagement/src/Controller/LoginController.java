package Controller;
import DBconnection.DBhandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import static javafx.fxml.FXMLLoader.load;


public class LoginController implements Initializable {


    @FXML
    private Button SignIn;

    @FXML
    private PasswordField Passwordtxt;

    @FXML
    private TextField UserId;

    @FXML
    private Button SignUp;

    @FXML
    private Label loginmessage;

    private Connection connection;
    private DBhandler handler;
    private PreparedStatement pst;
    private cidgenerater nn;
   /// private Storage store;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
            handler = new DBhandler();
    }
    public void loginaction(ActionEvent event) throws Exception {
       // store = new Storage();
        connection = handler.getConnection();

        String q="Select * from login where User_ID=? and Password=?";
        pst=connection.prepareStatement(q);
        pst.setString(1,UserId.getText());
        pst.setString(2,Passwordtxt.getText());
        ResultSet rs= pst.executeQuery();
        int count =0 ;
        String cid = "";
        while(rs.next()){
            cid=cid+rs.getString("C_ID");
            count++;

        }
        if(count==0){
            String ab= loginmessage.textProperty().get();
            loginmessage.textProperty().set("Userid or password is invalid");

        }
        else {
            if (cid.charAt(2) == 'A') {
                SignIn.getScene().getWindow().hide();
                Stage sin = new Stage();


                Parent root = load(getClass().getResource("/FXML/administrator.fxml"));

                sin.setTitle("Admin");
                sin.setScene(new Scene(root));
                sin.show();
                sin.setResizable(false);
            } else {
                nn=new cidgenerater();
                nn.CID=cid;

                Stage signup = new Stage();
                Parent root = load(getClass().getResource("/FXML/ReservationB.fxml"));

                signup.setTitle("Reserve");
                signup.setScene(new Scene(root, 884, 643));

                signup.show();
                signup.setResizable(false);

            }
        }
        connection.close();


    }



    public void signupaction(javafx.event.ActionEvent actionEvent) throws IOException {
        
        Stage signup=new Stage();
        Parent root= load(getClass().getResource("/FXML/SignUp.fxml"));
        signup.setTitle("SignUp");
        Scene scene= new Scene(root);
        signup.setScene(scene);
        signup.show();
        signup.setResizable(false);
    }



}
