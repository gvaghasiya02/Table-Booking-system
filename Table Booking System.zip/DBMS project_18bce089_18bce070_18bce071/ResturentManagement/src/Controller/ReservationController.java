package Controller;

import DBconnection.DBhandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import org.controlsfx.control.textfield.AutoCompletionBinding;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;

import static org.controlsfx.control.textfield.TextFields.bindAutoCompletion;

public class ReservationController implements Initializable {
    @FXML
    private Label CustomerIdtxt;

    @FXML
    private Label cidtxt;

    @FXML
    private Label nametxt;

    @FXML
    private Label email;

    @FXML
    private Label MobilNotxt;

    @FXML
    private DatePicker Date;

    @FXML
    private TextField time;

    @FXML
    private TextField Resturentname;

    @FXML
    private RadioButton radio1;

    @FXML
    private ToggleGroup tt;

    @FXML
    private RadioButton radio4;

    @FXML
    private RadioButton radio3;

    @FXML
    private RadioButton radio2;

    @FXML
    private Button submitreserve;

    @FXML
    private Button cdtxt;


    private AutoCompletionBinding<String> autoCompletionBinding;

    private String[] possibleSuggestions ={};
    private cidgenerater cii;
    private Set<String> possibleSuggestion = new HashSet<>();
    private Connection connection;
    private DBhandler handler;
    private PreparedStatement pst;
    private PreparedStatement pst1;
    private PreparedStatement pst2;
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        handler = new DBhandler();
        String q1 = "select Res_Name from restaurant";
        connection = handler.getConnection();
        try {
            pst1 = connection.prepareStatement(q1);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        ResultSet set1 = null;
        try {
            set1 = pst1.executeQuery();

            while (set1.next()) {
                possibleSuggestion.add(set1.getString("Res_Name"));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        bindAutoCompletion(Resturentname, possibleSuggestion);
        try {
            connection.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

        public void ciddetail (javafx.event.ActionEvent event){
            // handler = new DBhandler();
            cii = new cidgenerater();
            System.out.println(cii.CID);

            connection = handler.getConnection();
            String q = "select * from project.customer where C_ID  = ?";

            try {
                pst = connection.prepareStatement(q);

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            try {
                pst.setString(1, cii.CID);
                ResultSet set = pst.executeQuery();

                while (set.next()) {
                    System.out.println(cii.CID);
                    cidtxt.textProperty().get();
                    cidtxt.textProperty().set(("C_ID: " + set.getString("C_ID")));
                    nametxt.textProperty().get();
                    nametxt.textProperty().set("Name: " + set.getString("Name"));
                    email.textProperty().get();
                    email.textProperty().set("E-mail: " + set.getString("Email"));
                    MobilNotxt.textProperty().get();
                    MobilNotxt.textProperty().set("Mobile_No.: " + set.getString("MobileNo"));


                }

            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

            //bindAutoCompletion(Resturentname,possibleSuggestion);
            try {
                connection.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

            // bindAutoCompletion(Resturentname,possibleSuggestion);

        }
        public void submitR (javafx.event.ActionEvent event){
            handler = new DBhandler();
            String s1 = null,s2 = null,s3,s4,q3;
            connection = handler.getConnection();
            String q = "select tl.T_ID,tl.Res_ID  From (Select T_ID,Res_ID from project.Reservation where Res_Name = ? and No_of_Guests = ?  and  Date(R_date) = Date(?) and TIMEDIFF(R_Time,?) Between  TIME(\"00:00:00\") and TIME(\"00:20:00\")) as tt \n" +
                    "Right join (Select T_ID,tableno.Res_ID from project.tableno RIGHT JOIN project.restaurant ON tableno.Res_ID=restaurant.Res_ID where Res_Name = ? and Capacity = ? ) as tl \n" +
                    " on (tt.T_ID!=tl.T_ID and tt.Res_ID = tl.Res_ID)\n" +
                    " ;" ;

            try {
                pst=connection.prepareStatement(q);

                pst.setString(1,Resturentname.getText());
                pst.setString(2,((radio1.isSelected())?"1":(radio2.isSelected())?"2":(radio3.isSelected())?"3":(radio4.isSelected())?"4":"1"));
                pst.setString(3, String.valueOf(Date.getValue()));
                pst.setString(4,time.getText()+":00");
                pst.setString(5,Resturentname.getText());
                pst.setString(6,((radio1.isSelected())?"1":(radio2.isSelected())?"2":(radio3.isSelected())?"3":(radio4.isSelected())?"4":"1"));
                ResultSet set= pst.executeQuery();

                int count=0,co=0;
                while(set.next()){
                    s1=set.getString("T_ID");
                    s2=set.getString("Res_ID");
                    count++;

                }

                if(count!=0){
                    q3 = "insert into reservation (Res_Name,Res_ID,R_Time,R_date,No_of_Guests,C_ID,T_ID) Values (?,?,?,?,?,?,?)";
                    pst2= connection.prepareStatement(q3);
                    pst2.setString(1,Resturentname.getText());
                    pst2.setString(2,s2);
                    pst2.setString(3,time.getText()+":00");
                    pst2.setString(4, String.valueOf(Date.getValue()));
                    pst2.setString(5,((radio1.isSelected())?"1":(radio2.isSelected())?"2":(radio3.isSelected())?"3":(radio4.isSelected())?"4":"1"));
                    pst2.setString(6,cii.CID);
                    pst2.setString(7,s1);
                    int get = pst2.executeUpdate();
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Conformation");

                    // Header Text: null
                    alert.setHeaderText(null);
                    alert.setContentText("Your Table is booked");

                    alert.showAndWait();
                    submitreserve.getScene().getWindow().hide();

                }
                else
                {   Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Conformation");

                    // Header Text: null
                    alert.setHeaderText(null);
                    alert.setContentText("Table is Full ,try other table");

                    alert.showAndWait();
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }

        }

    }







