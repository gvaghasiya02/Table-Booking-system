package Controller;

import javafx.beans.property.SimpleStringProperty;

public class ResevationTable {
    private final SimpleStringProperty C_ID;
    private final SimpleStringProperty R_ID;
    private final SimpleStringProperty Rname;
    private final SimpleStringProperty T_ID;
    private final SimpleStringProperty R_Date;
    private final SimpleStringProperty R_Time;
    private final SimpleStringProperty no;


    public ResevationTable(String c_ID, String r_ID, String rname, String t_ID, String r_Date, String r_Time, String No) {
        C_ID = new SimpleStringProperty(c_ID);
        R_ID = new SimpleStringProperty( r_ID );
        Rname = new SimpleStringProperty( rname);
        T_ID = new SimpleStringProperty( t_ID);
        R_Date =new SimpleStringProperty( r_Date);
        R_Time =new SimpleStringProperty( r_Time);
        no = new SimpleStringProperty(No);
    }
    public String getC_ID() {
        return C_ID.get();
    }
    public String getR_ID() {
        return R_ID.get();
    }

    public String getRname() {
        return Rname.get();
    }

    public String getT_ID() {
        return T_ID.get();
    }

    public String getR_Date() {
        return R_Date.get();
    }

    public String getR_Time() {
        return R_Time.get();
    }

    public String getNo() {
        return no.get();
    }



}
