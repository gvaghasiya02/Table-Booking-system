package Controller;

public class cidgenerater {
    protected static int a=50;
    protected static String s="20C";
    protected static String CID="";
}
