package Controller;

import DBconnection.DBhandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ReservationTableController implements Initializable {
    @FXML
    private TableView<ResevationTable> RservationTable;
    @FXML
    private javafx.scene.control.TableColumn<ResevationTable, String> C_ID;

    @FXML
    private javafx.scene.control.TableColumn<ResevationTable, String> RName;

    @FXML
    private javafx.scene.control.TableColumn<ResevationTable, String> R_ID;

    @FXML
    private javafx.scene.control.TableColumn<ResevationTable, String> T_ID;

    @FXML
    private javafx.scene.control.TableColumn<ResevationTable, String> R_Date;

    @FXML
    private javafx.scene.control.TableColumn<ResevationTable, String> R_Time;

    @FXML
    private TableColumn<ResevationTable, Integer> no;
    ObservableList<ResevationTable> list= FXCollections.observableArrayList();
    private Connection connection;
    private DBhandler handler;
    private PreparedStatement pst;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        handler = new DBhandler();
        connection = handler.getConnection();
        String q="select * from reservation";
        try {
            pst = connection.prepareStatement(q);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            ResultSet rs= pst.executeQuery();
            while (rs.next()){
                String x,x1,x2,x3,x4,x5 = null,x6;
                x=rs.getString("C_ID");x1=rs.getString("Res_ID");x2=rs.getString("Res_Name");x3=rs.getString("T_ID");x4=rs.getString("R_date");x5=rs.getString("R_time");x6=rs.getString("No_of_Guests");
                System.out.println(x+" "+x1+" "+x2+" "+x3+" "+x4+" "+x5+" "+x6);
                list.add(new ResevationTable(rs.getString("C_ID"),rs.getString("Res_ID"),rs.getString("Res_Name"),rs.getString("T_ID"),rs.getString("R_date"),rs.getString("R_time"),rs.getString("No_of_Guests")));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        C_ID.setCellValueFactory(new PropertyValueFactory<ResevationTable, String>("C_ID"));
        R_ID.setCellValueFactory(new PropertyValueFactory<ResevationTable, String>("R_ID"));
        RName.setCellValueFactory(new PropertyValueFactory<ResevationTable, String>("Rname"));

        T_ID.setCellValueFactory(new PropertyValueFactory<ResevationTable, String>("T_ID"));
        R_Date.setCellValueFactory(new PropertyValueFactory<ResevationTable, String>("R_Date"));
        R_Time.setCellValueFactory(new PropertyValueFactory<ResevationTable, String>("R_Time"));
        no.setCellValueFactory(new PropertyValueFactory<>("no"));
        RservationTable.setItems(list);

    }
}
