package Controller;

import DBconnection.DBhandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class Editcontroller implements Initializable {
    private Connection connection;
    private DBhandler handler;
    private PreparedStatement pst;
    @FXML
    private TextField sqlquery;

    @FXML
    private Button submitquery;
    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
    public void presssubmit (javafx.event.ActionEvent event){
        handler = new DBhandler();
        connection = handler.getConnection();
        String q= sqlquery.textProperty().get();

        try {
            pst = connection.prepareStatement(q);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            ResultSet rs= pst.executeQuery();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            connection.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

}
