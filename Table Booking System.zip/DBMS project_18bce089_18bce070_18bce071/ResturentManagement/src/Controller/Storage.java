package Controller;

public class Storage {
    public static String cid=null;

}
