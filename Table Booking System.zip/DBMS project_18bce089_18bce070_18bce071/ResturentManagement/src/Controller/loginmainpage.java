package Controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static javafx.fxml.FXMLLoader.load;

public class loginmainpage implements Initializable {
    @FXML
    private ImageView imagevv;

    @FXML
    private Button press;

    @FXML
    private ImageView r2;

    @FXML
    private ImageView r3;

    @FXML
    private ImageView r4;


    public void pressbut(javafx.event.ActionEvent event) throws IOException {
        Stage signup=new Stage();
        Parent root= load(getClass().getResource("/FXML/login.fxml"));
        signup.setTitle("Login");
        Scene scene= new Scene(root);
        signup.setScene(scene);
        signup.show();
        signup.setResizable(false);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        try {
            Image im = new Image(new FileInputStream("C:\\Users\\PRANAV KANSAGRA\\IdeaProjects\\ResturentManagement\\images\\2.jpg"));
            imagevv.setImage(im);
            Image in= new Image(new FileInputStream("C:\\Users\\PRANAV KANSAGRA\\IdeaProjects\\ResturentManagement\\images\\r2.jpg"));
            Image it= new Image(new FileInputStream("C:\\Users\\PRANAV KANSAGRA\\IdeaProjects\\ResturentManagement\\images\\r3.jpg"));
            Image iw= new Image(new FileInputStream("C:\\Users\\PRANAV KANSAGRA\\IdeaProjects\\ResturentManagement\\images\\r4.jpg"));
            r2.setImage(in);
            r3.setImage(it);
            r4.setImage(iw);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
}
