package Controller;

import DBconnection.DBhandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
public class CustomerTableController implements Initializable {
    @FXML
    private TableView<CustomerTable> customertxt;

    @FXML
    private TableColumn<CustomerTable, String> C_ID;

    @FXML
    private TableColumn<CustomerTable, String> C_Name;

    @FXML
    private TableColumn<CustomerTable, String> E_mail;

    @FXML
    private TableColumn<CustomerTable, String> MobileNo;

    @FXML
    private TableColumn<CustomerTable, String> Adress;

    ObservableList<CustomerTable> list= FXCollections.observableArrayList();
    private Connection connection;
    private DBhandler handler;
    private PreparedStatement pst;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        handler = new DBhandler();
        connection = handler.getConnection();
        String q="select C_ID,MobileNo,Address,Email,Name from customer";
        try {
            pst = connection.prepareStatement(q);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        try {
            ResultSet rs= pst.executeQuery();
            while (rs.next()){
                list.add(new CustomerTable(rs.getNString("C_ID"),rs.getNString("MobileNo"),rs.getNString("Address"),rs.getNString("Email"),rs.getNString("Name")));
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        C_ID.setCellValueFactory(new PropertyValueFactory<>("C_ID"));
        MobileNo.setCellValueFactory(new PropertyValueFactory<>("MobileNo"));
        Adress.setCellValueFactory(new PropertyValueFactory<>("Adress"));
        E_mail.setCellValueFactory(new PropertyValueFactory<>("E_mail"));
        C_Name.setCellValueFactory(new PropertyValueFactory<>("C_Name"));

        customertxt.setItems(list);
    }
}
