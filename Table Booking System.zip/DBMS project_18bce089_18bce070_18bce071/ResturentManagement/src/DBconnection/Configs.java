package DBconnection;

public class Configs {
    protected static String dbhost = "localhost";

    protected static String dbport = "3307";
    protected static String dbname = "project";
    protected static String dbuser = "root";
    protected static String dbpass = "Pranav@2000";

}
