package DBconnection;

import java.sql.*;

public class DBhandler extends Configs {
    private static Connection dbconnection;


    public static Connection getConnection(){

        String connectionString ="jdbc:mysql://"+Configs.dbhost + ":" +Configs.dbport + "/" + Configs.dbname;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");

        }
        catch (Exception e){
            e.printStackTrace();
        }
        try {
            dbconnection = DriverManager.getConnection(connectionString,Configs.dbuser,Configs.dbpass);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return dbconnection;
    }


}
