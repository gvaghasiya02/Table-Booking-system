package mysqlaction;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;




class sample1
{
    public static void main(String args[])
    {
        try
        {	//System.out.println("Print");
            Class.forName("com.mysql.jdbs.Driver");
            // String url="jdbc:mysql://localhost:3307/youtube";
        }
        catch(Exception e)
        {


        }

        String url="jdbc:mysql://localhost:3307/youtube";
        String username="root";
        System.out.println("Print");
        String password="Pranav@2000";
        System.out.println("Print");
        try{
            System.out.println("Print");
            Connection con = DriverManager.getConnection(url,username,password);
            String q="CREATE TABLE IF NOT EXISTS administrator (\n" +
                    "  A_ID varchar(8) NOT NULL,\n" +
                    "  Name varchar(50) NOT NULL,\n" +
                    "  E_mail varchar(50) NOT NULL,\n" +
                    "  Mobile_No varchar(10) NOT NULL,\n" +
                    "  PRIMARY KEY ( A_ID )\n" +
                    "); ";
            Statement stmt = con.createStatement();
            stmt.executeUpdate(q);
            System.out.println("table created");
            con.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();

        }



    }
}
